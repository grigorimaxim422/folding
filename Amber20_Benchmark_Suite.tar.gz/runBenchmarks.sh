#!/bin/bash

ARGV=( "$@" )
NARG=$#
let "NARGM1=${NARG} - 1"

# Default parameters
RUNID="X"
NCORE=4
SKIPSCPU=0
SKIPPCPU=0
SKIPSGPU=0
SKIPMGPU=0
SPEC_GPU="ALL"
PRHELP=0
DOCLEAN=0

# Take in command-line arguments
I=0
NGPU=-1
while [ ${I} -lt ${NARG} ] ; do
  let "IP1=${I} + 1"
  if [ ${IP1} -lt ${NARG} ] ; then
    if [ ${ARGV[${I}]} == "-NGPU" ] ; then
      NGPU=${ARGV[${IP1}]}
    fi
    if [ ${ARGV[${I}]} == "-RUNID" ] ; then
      RUNID=${ARGV[${IP1}]}
    fi
    if [ ${ARGV[${I}]} == "-NCORE" ] ; then
      NCORE=${ARGV[${IP1}]}
    fi
    if [ ${ARGV[${I}]} == "-SPEC_GPU" ] ; then
      SPEC_GPU=${ARGV[${IP1}]}
    fi
  fi
  if [ ${ARGV[${I}]} == "-SKIP_CPU" ] ; then
    SKIPSCPU=1
    SKIPPCPU=1
  fi
  if [ ${ARGV[${I}]} == "-SKIP_GPU" ] ; then
    NGPU=0
    SPEC_GPU="NONE"  
  fi
  if [ ${ARGV[${I}]} == "-SKIP_SGPU" ] ; then
    SKIPSGPU=1
  fi
  if [ ${ARGV[${I}]} == "-SKIP_MGPU" ] ; then
    SKIPMGPU=1
  fi
  if [ ${ARGV[${I}]} == "-SKIP_SERIAL_CPU" ] ; then
    SKIPSCPU=1
  fi
  if [ ${ARGV[${I}]} == "-SKIP_PARALLEL_CPU" ] ; then
    SKIPPCPU=1
  fi
  if [ ${ARGV[${I}]} == "-HELP" ] && [ ${NARG} -eq 1 ] ; then
    PRHELP=1
  fi
  if [ ${ARGV[${I}]} == "--help" ] && [ ${NARG} -eq 1 ] ; then
    PRHELP=1
  fi
  if [ ${ARGV[${I}]} == "-CLEAN" ] ; then
    DOCLEAN=1
  fi
  let "I+=1"
done
if [ ${NARG} -eq 0 ] ; then
  PRHELP=2
fi

if [ ${PRHELP} -gt 0 ] ; then
  echo
  echo "Usage: ./runBenchmarks.sh [ -NGPU <number>, -RUNID <string>, -NCORE <number>, "
  echo "                            -SPEC_GPU <gpu ids> ]"
  echo "                          [ -SKIP_CPU, -SKIP_SERIAL_CPU, -SKIP_PARALLEL_CPU "
  echo "                            -SKIP_GPU, -HELP, --help, -CLEAN ]"
  echo
  echo "Options:"
  echo "  -NGPU     :: the number of GPUs in the system (default behavior is to use "
  echo "               nvidia-smi to count the number of GPUs).  This can also be "
  echo "               used to request benchmarks on the first NGPU cards, as "
  echo "               enumerated by \${CUDA_VISIBLE_DEVICES}."
  echo "  -RUNID    :: identification tag to leave on all run output files "
  echo "  -NCORE    :: the number of CPU cores in the system (relevant for running "
  echo "               serial CPU tests in parallel and the degree of parallelism in "
  echo "               pmemd.MPI tests"
  echo "  -SPEC_GPU :: followed by a string of integers delimited by commas (no spaces)"
  echo "               such as '0,3,4,6' to indicate the GPU IDs to benchmark.  This "
  echo "               can be fed the value of \${CUDA_VISIBLE_DEVICES}, for example."
  echo "               The default behavior is to benchmark all GPUs, one by one."
  echo
  echo "  -SKIP_CPU           :: skip all CPU benchmarks"
  echo "  -SKIP_SERIAL_CPU    :: skip serial CPU benchmarks"
  echo "  -SKIP_PARALLEL_CPU  :: skip parallel CPU benchmarks"
  echo "  -SKIP_GPU           :: skip GPU benchmarks"
  echo
  echo "  -HELP, --help  :: print the help message (exit if this is the only argument)"
  echo "  -CLEAN         :: clear previous results corresponding to \${RUNID}.  This "
  echo "                    script takes \${RUNID} as a means of keeping multiple "
  echo "                    benchmarks simultaneously.  Furthermore, results bearing "
  echo "                    a given \${RUNID} will be accepted by the script  when "
  echo "                    found, rather than repeating the test."
  echo
  echo "NOTE: for those really interested in serial CPU tests, in order to accelerate "
  echo "      them this script will run as many independent tests simultaneously as "
  echo "      the CPU cores allow.  However, this may cause serial CPU tests to "
  echo "      compete for chip cache, slowing each of them down somewhat.  For the "
  echo "      best possible single CPU speed, run these benchmarks with:"
  echo
  echo "  $0 -SKIP_GPU -SKIP_PARALLEL_CPU -NCORE 1"
  echo
  if [ ${PRHELP} -eq 1 ] ; then
    exit
  fi
fi

# System specifications
PME_SYS="JAC_production_NVE_4fs JAC_production_NPT_4fs Cellulose_production_NVE_4fs \
         Cellulose_production_NPT_4fs FactorIX_production_NVE_4fs \
         FactorIX_production_NPT_4fs STMV_production_NVE_4fs STMV_production_NPT_4fs"
GB_SYS="TRPCage myoglobin nucleosome"

# Get the number of GPUs
if [ ${CUDA_HOME} ] ; then
  if [ ${NGPU} -eq -1 ] || [ ${SPEC_GPU} == "ALL" ] ; then
    NGPU=`nvidia-smi | grep "[0-9]C    P" | wc -l`
  fi
fi

# Make the array of GPU IDs
if [ ${NGPU} -ne 0 ] ; then
  declare -A GPU_ARRAY
  if [ ${SPEC_GPU} == "ALL" ] ; then
    I=0
    while [ ${I} -lt ${NGPU} ] ; do  
      GPU_ARRAY[${I}]=${I}
      let "I+=1"
    done
  else
    P_ARRAY=$(echo ${SPEC_GPU} | sed "s/,/ /g")
    J=0
    for I in ${P_ARRAY} ; do
      GPU_ARRAY[${J}]=${I}
      let "J+=1"
    done
  fi
  if [ ${#GPU_ARRAY[@]} -gt ${NGPU} ] ; then
    echo "Error :: A number of GPUs has been requested that exceeds system contents."
    exit
  fi
  TNGPU=0
  for CVD in ${GPU_ARRAY[@]} ; do
    if [ ${CVD} -ge ${NGPU} ] ; then
      echo "Error :: Invalid GPU ID ${CVD}"
      exit
    fi
    let "TNGPU+=1"
  done
  NGPU=${TNGPU}
fi

# Do cleaning if requested, then stop
if [ ${DOCLEAN} -eq 1 ] ; then
  echo "Clearing previous results for run ${RUNID}"
  for SUFF in .opt.out .out .r .x ; do
    for EXT in ${RUNID} m${RUNID} ; do
      for SYS in ${PME_SYS} ; do
        I=0	    
        while [ ${I} -lt ${NGPU} ] ; do
          if [ -e PME/${SYS}/md${GPU_ARRAY[${I}]}_${EXT}${SUFF} ] ; then
            rm PME/${SYS}/md${GPU_ARRAY[${I}]}_${EXT}${SUFF}
          fi
          let "I+=1"
        done
      done
      for SYS in ${GB_SYS} ; do
        I=0	    
        while [ ${I} -lt ${NGPU} ] ; do
          if [ -e GB/${SYS}/md${GPU_ARRAY[${I}]}_${EXT}${SUFF} ] ; then
            rm GB/${SYS}/md${GPU_ARRAY[${I}]}_${EXT}${SUFF}
          fi
          let "I+=1"
        done
      done
    done
  done
  exit
fi

# Report what will happen
echo "\${AMBERHOME} is set to ${AMBERHOME}"
if [ ${SKIPSCPU} -eq 1 ]; then
  echo "Serial CPU benchmarks will be SKIPPED"
fi
if [ ${SKIPPCPU} -eq 1 ]; then
  echo "Parallel CPU benchmarks will be SKIPPED"
else
  echo "Parallel CPU benchmarks will be run for ${NCORE} CPU cores"
fi
if [ ${NGPU} -gt 0 ] ; then
  GARRAY=""
  I=0
  while [ ${I} -lt ${NGPU} ] ; do
    GARRAY="${GARRAY} ${GPU_ARRAY[${I}]}"
    let "I+=1"
  done
  echo "Serial GPU benchmarks will be run for ${NGPU} GPUs: ${GARRAY}"
fi

# Set convenient variables
let "NGPUP2=${NGPU} + 2"

# Lay out an array of results for CPU runs and each GPU
I=0
declare -A PMETIME
declare -A PMEOPTTIME
declare -A mPMETIME
declare -A mPMEOPTTIME
for SYS in ${PME_SYS} ; do
  J=0
  while [ ${J} -lt ${NGPU} ] ; do
    let "IJ=${NGPUP2}*${I} + ${J}"
    PMETIME[${IJ}]="   "
    PMEOPTTIME[${IJ}]="   "
    mPMETIME[${IJ}]="   "
    mPMEOPTTIME[${IJ}]="   "
    let "J+=1"
  done
  let "I+=1"
done
I=0
declare -A GBTIME
declare -A mGBTIME
for SYS in ${GB_SYS} ; do
  J=0
  while [ ${J} -lt ${NGPU} ] ; do
    let "IJ=${NGPUP2}*${I} + ${J}"
    GBTIME[${IJ}]="   "
    mGBTIME[${IJ}]="   "
    let "J+=1"
  done
  let "I+=1"
done

# Perform serial CPU runs
STYLES=""
if [ ${SKIPSCPU} -eq 0 ] ; then
  STYLES="${STYLES} CPU"
fi
if [ ${SKIPPCPU} -eq 0 ] ; then
  STYLES="${STYLES} XCPU"
fi

NS=0
for STYLE in ${STYLES} ; do
  COMPLETE=1
  for SYS in ${PME_SYS} ; do
    if [ ! -e PME/${SYS}/md${STYLE}_${RUNID}.out ] ; then
      COMPLETE=0
    fi
  done
  for SYS in ${GB_SYS} ; do
    if [ ! -e GB/${SYS}/md${STYLE}_${RUNID}.out ] ; then
      COMPLETE=0
    fi
  done
  if [ ${COMPLETE} -eq 0 ] ; then
    if [ ${STYLE} == "CPU" ] ; then
      echo "Engaging serial CPU tests"
      PMEMD="${AMBERHOME}/bin/pmemd"
    else
      echo "Engaging parallel CPU tests"
      PMEMD="mpirun -np ${NCORE} ${AMBERHOME}/bin/pmemd.MPI"
    fi
  fi
  
  # Execute CPU PME tests
  if [ ${STYLE} == "CPU" ] ; then
    let "NJOB=0"
  fi
  for SYS in ${PME_SYS} ; do
    if [ ${COMPLETE} -eq 0 ] ; then
      echo "System: ${SYS} (PME)"
    fi
    cd PME/${SYS}/
    if [ ! -e md${STYLE}_${RUNID}.out ] ; then
      if [ ${STYLE} == "CPU" ] ; then
        ${PMEMD} -O \
          -i mdin.CPU \
          -p ../Topologies/${SYS%%_production*}.prmtop \
          -c ../Coordinates/${SYS%%_production*}.inpcrd \
          -o md${STYLE}_${RUNID}.out \
          -x md${STYLE}_${RUNID}.x \
          -r md${STYLE}_${RUNID}.r \
          -e md${STYLE}_${RUNID}.e &
	let "NJOB+=1"
      else
        ${PMEMD} -O \
          -i mdin.CPU \
          -p ../Topologies/${SYS%%_production*}.prmtop \
          -c ../Coordinates/${SYS%%_production*}.inpcrd \
          -o md${STYLE}_${RUNID}.out \
          -x md${STYLE}_${RUNID}.x \
          -r md${STYLE}_${RUNID}.r \
          -e md${STYLE}_${RUNID}.e
      fi
    fi
    cd ../../
    if [ ${NJOB} -eq ${NCORE} ] ; then
      NJOB=0
      wait	
    fi
  done

  # Execute CPU GB tests
  for SYS in ${GB_SYS} ; do
    if [ ${COMPLETE} -eq 0 ] ; then
      echo "System: ${SYS} (GB)"
    fi
    cd GB/${SYS}/
    if [ ! -e md${STYLE}_${RUNID}.out ] ; then
      if [ ${STYLE} == "CPU" ] ; then
	${PMEMD} -O \
          -i mdin.CPU \
          -p prmtop \
          -c inpcrd \
          -o md${STYLE}_${RUNID}.out \
          -x md${STYLE}_${RUNID}.x \
          -r md${STYLE}_${RUNID}.r \
          -e md${STYLE}_${RUNID}.e &
	let "NJOB+=1"
      else
	${PMEMD} -O \
          -i mdin.CPU \
          -p prmtop \
          -c inpcrd \
          -o md${STYLE}_${RUNID}.out \
          -x md${STYLE}_${RUNID}.x \
          -r md${STYLE}_${RUNID}.r \
          -e md${STYLE}_${RUNID}.e
      fi
    fi
    cd ../../
    if [ ${NJOB} -eq ${NCORE} ] ; then
      NJOB=0
      wait	
    fi
  done
  if [ ${STYLE} == "CPU" ] ; then
    wait
  fi
    
  I=0
  for SYS in ${PME_SYS} ; do
    cd PME/${SYS}/      
    GG=`grep "ns/day" md${STYLE}_${RUNID}.out | tail -n1 | awk {'print $4'}`
    GG=`printf "%8.2f" ${GG}`
    let "IJ=${NGPUP2}*${I} + ${NS}"
    PMETIME[${IJ}]=${GG}
    if [ ${COMPLETE} -eq 0 ] ; then
      echo "  Standard production rate,  ${STYLE}: ${GG}"
    fi
    cd ../../
    let "I+=1"
  done
  I=0
  for SYS in ${GB_SYS} ; do
    cd GB/${SYS}/
    GG=`grep "ns/day" md${STYLE}_${RUNID}.out | tail -n1 | awk {'print $4'}`
    GG=`printf "%8.2f" ${GG}`
    let "IJ=${NGPUP2}*${I} + ${NS}"
    GBTIME[${IJ}]=${GG}
    if [ ${COMPLETE} -eq 0 ] ; then
      echo "  Standard production rate,  ${STYLE}: ${GG}"
    fi
    cd ../../
    let "I+=1"
  done

  # Increment the style counter
  let "NS+=1"
done

# Warm up the GPU with a dry run, then kill it and start running real stuff
if [ ${SKIPSGPU} -eq 0 ] ; then
  CVD=0
  while [ ${CVD} -lt ${NGPU} ] ; do

    # Set the GPU to use
    export CUDA_VISIBLE_DEVICES=${GPU_ARRAY[${CVD}]}

    # Check for completeness
    COMPLETE=1
    for SYS in ${PME_SYS} ; do
      if [ ! -e PME/${SYS}/md${CVD}_${RUNID}.out ] ; then
        COMPLETE=0
      fi
    done
    for SYS in ${GB_SYS} ; do
      if [ ! -e GB/${SYS}/md${CVD}_${RUNID}.out ] ; then
        COMPLETE=0
      fi
    done

    # Warm up the GPU if any tests are incomplete
    if [ ${COMPLETE} -eq 0 ] ; then
      echo "Warming up GPU ${CVD}..."
      cd PME/Cellulose_production_NPT_4fs/
      ${AMBERHOME}/bin/pmemd.cuda -O \
        -i mdin.GPU \
        -p ../Topologies/Cellulose.prmtop \
        -c ../Coordinates/Cellulose.inpcrd \
        -o md${CVD}.out \
        -x md${CVD}.x \
        -r md${CVD}.r \
        -e md${CVD}.e
      cd ../../
    fi
  
    I=0
    for SYS in ${PME_SYS} ; do
      if [ ${COMPLETE} -eq 0 ] ; then
        echo "System: ${SYS} (PME)"
      fi
      cd PME/${SYS}/

      # Restart all runs with warmed-up GPUs
      CREPORT=0
      if [ ! -e md${CVD}_${RUNID}.out ] ; then
        ${AMBERHOME}/bin/pmemd.cuda -O \
          -i mdin.GPU \
          -p ../Topologies/${SYS%%_production*}.prmtop \
          -c ../Coordinates/${SYS%%_production*}.inpcrd \
          -o md${CVD}_${RUNID}.out \
          -x md${CVD}_${RUNID}.x \
          -r md${CVD}_${RUNID}.r \
          -e md${CVD}_${RUNID}.e
        CREPORT=1
      fi
      GG=`grep "ns/day" md${CVD}_${RUNID}.out | tail -n1 | awk {'print $4'}`
      GG=`printf "%8.2f" ${GG}`
      let "IJ=${NGPUP2}*${I} + 2 + ${CVD}"
      PMETIME[${IJ}]=${GG}
      if [ ${CREPORT} -eq 1 ] ; then
        echo "  Standard production rate,  GPU ${CVD}: ${GG}"
      fi

      # Restart all runs with warmed-up GPUs, optimized settings
      CREPORT=0
      if [ ! -e md${CVD}_${RUNID}.opt.out ] ; then
        ${AMBERHOME}/bin/pmemd.cuda -O \
          -i mdinOPT.GPU \
          -p ../Topologies/${SYS%%_production*}.prmtop \
          -c ../Coordinates/${SYS%%_production*}.inpcrd \
          -o md${CVD}_${RUNID}.opt.out \
          -x md${CVD}_${RUNID}.x \
          -r md${CVD}_${RUNID}.r \
          -e md${CVD}_${RUNID}.e 
        CREPORT=1
      fi
      GG=`grep "ns/day" md${CVD}_${RUNID}.opt.out | tail -n1 | awk {'print $4'}`
      GG=`printf "%8.2f" ${GG}`
      PMEOPTTIME[${IJ}]=${GG}
      if [ ${CREPORT} -eq 1 ] ; then
        echo "  Optimized production rate, GPU ${CVD}: ${GG}"
      fi
      cd ../../
      let "I+=1"
    done
    echo

    I=0
    for SYS in ${GB_SYS} ; do
      if [ ${COMPLETE} -eq 0 ] ; then
        echo "System: ${SYS} (GB)"
      fi
      cd GB/${SYS}/

      # Restart all runs with warmed-up GPUs, optimized settings
      CREPORT=0
      if [ ! -e md${CVD}_${RUNID}.out ] ; then
        ${AMBERHOME}/bin/pmemd.cuda -O \
          -i mdin.GPU \
          -p prmtop \
          -c inpcrd \
          -o md${CVD}_${RUNID}.out \
          -x md${CVD}_${RUNID}.x \
          -r md${CVD}_${RUNID}.r \
          -e md${CVD}_${RUNID}.e
        CREPORT=1
      fi
      GG=`grep "ns/day" md${CVD}_${RUNID}.out | tail -n1 | awk {'print $4'}`
      GG=`printf "%8.2f" ${GG}`
      let "IJ=${NGPUP2}*${I} + 2 + ${CVD}"
      GBTIME[${IJ}]=${GG}
      if [ ${CREPORT} -eq 1 ] ; then
        echo "  Optimized production rate, GPU ${CVD}: ${GG}"
      fi
      cd ../../
      let "I+=1"
    done

    let "CVD+=1"
  done
fi

if [ ${SKIPMGPU} -eq 0 ] ; then
  I=0
  for SYS in ${PME_SYS} ; do
    
    # Run all GPU tests if any tests are incomplete
    COMPLETE=1
    CVD=0
    while [ ${CVD} -lt ${NGPU} ] ; do
      if [ ! -e PME/${SYS}/md${CVD}_m${RUNID}.out ] ; then
        COMPLETE=0
      fi
      let "CVD+=1"
    done
    CREPORT=0
    if [ ${COMPLETE} -eq 0 ] ; then
      cd PME/${SYS}/
      CVD=0
      while [ ${CVD} -lt ${NGPU} ] ; do
        export CUDA_VISIBLE_DEVICES=${GPU_ARRAY[${CVD}]}
        ${AMBERHOME}/bin/pmemd.cuda -O \
          -i mdin.GPU \
          -p ../Topologies/${SYS%%_production*}.prmtop \
          -c ../Coordinates/${SYS%%_production*}.inpcrd \
          -o md${CVD}_m${RUNID}.out \
          -x md${CVD}_m${RUNID}.x \
          -r md${CVD}_m${RUNID}.r \
          -e md${CVD}_m${RUNID}.e &
        CREPORT=1
        let "CVD+=1"
      done
      cd ../../
      wait
    fi
    CVD=0
    cd PME/${SYS}/
    while [ ${CVD} -lt ${NGPU} ] ; do
      GG=`grep "ns/day" md${CVD}_m${RUNID}.out | tail -n1 | awk {'print $4'}`
      GG=`printf "%8.2f" ${GG}`
      let "IJ=${NGPUP2}*${I} + 2 + ${CVD}"
      mPMETIME[${IJ}]=${GG}
      if [ ${CREPORT} -eq 1 ] ; then
        echo "  Standard production rate, mGPU ${CVD}: ${GG}"
      fi
      let "CVD+=1"
    done
    cd ../../

    # Run all optimized GPU tests if any are incomplete
    COMPLETE=1
    CVD=0
    while [ ${CVD} -lt ${NGPU} ] ; do
      if [ ! -e PME/${SYS}/md${CVD}_m${RUNID}.opt.out ] ; then
        COMPLETE=0
      fi
      let "CVD+=1"
    done
    CREPORT=0
    if [ ${COMPLETE} -eq 0 ] ; then
      cd PME/${SYS}/
      CVD=0
      while [ ${CVD} -lt ${NGPU} ] ; do
        export CUDA_VISIBLE_DEVICES=${GPU_ARRAY[${CVD}]}
        ${AMBERHOME}/bin/pmemd.cuda -O \
          -i mdinOPT.GPU \
          -p ../Topologies/${SYS%%_production*}.prmtop \
          -c ../Coordinates/${SYS%%_production*}.inpcrd \
          -o md${CVD}_m${RUNID}.opt.out \
          -x md${CVD}_m${RUNID}.x \
          -r md${CVD}_m${RUNID}.r \
          -e md${CVD}_m${RUNID}.e &
        CREPORT=1
        let "CVD+=1"
      done
      cd ../../
      wait
    fi
    CVD=0
    cd PME/${SYS}/
    while [ ${CVD} -lt ${NGPU} ] ; do
      GG=`grep "ns/day" md${CVD}_m${RUNID}.opt.out | tail -n1 | awk {'print $4'}`
      GG=`printf "%8.2f" ${GG}`
      let "IJ=${NGPUP2}*${I} + 2 + ${CVD}"
      mPMEOPTTIME[${IJ}]=${GG}
      if [ ${CREPORT} -eq 1 ] ; then
        echo "  Optimized production rate, mGPU ${CVD}: ${GG}"
      fi
      let "CVD+=1"
    done
    cd ../../

    let "I+=1"
  done

  I=0
  for SYS in ${GB_SYS} ; do

    # Run all GPU tests if any tests are incomplete
    COMPLETE=1
    CVD=0
    while [ ${CVD} -lt ${NGPU} ] ; do
      if [ ! -e GB/${SYS}/md${CVD}_m${RUNID}.out ] ; then
        COMPLETE=0
      fi
      let "CVD+=1"
    done
    CREPORT=0
    if [ ${COMPLETE} -eq 0 ] ; then
      cd GB/${SYS}/
      CVD=0
      while [ ${CVD} -lt ${NGPU} ] ; do
        export CUDA_VISIBLE_DEVICES=${GPU_ARRAY[${CVD}]}
        ${AMBERHOME}/bin/pmemd.cuda -O \
          -i mdin.GPU \
          -p prmtop \
          -c inpcrd \
          -o md${CVD}_m${RUNID}.out \
          -x md${CVD}_m${RUNID}.x \
          -r md${CVD}_m${RUNID}.r \
          -e md${CVD}_m${RUNID}.e &
        CREPORT=1
        let "CVD+=1"
      done
      cd ../../
      wait
    fi
    CVD=0
    cd GB/${SYS}/
    while [ ${CVD} -lt ${NGPU} ] ; do
      GG=`grep "ns/day" md${CVD}_m${RUNID}.out | tail -n1 | awk {'print $4'}`
      GG=`printf "%8.2f" ${GG}`
      let "IJ=${NGPUP2}*${I} + 2 + ${CVD}"
      mGBTIME[${IJ}]=${GG}
      if [ ${CREPORT} -eq 1 ] ; then
        echo "  Standard production rate, mGPU ${CVD}: ${GG}"
      fi
      let "CVD+=1"
    done
    cd ../../
    let "I+=1"
  done
fi

# Print report table headings
echo
echo "Report of all timings (ns/day):"
CVD=0
TT="            System                    Class       CPU (1) CPU (${NCORE})"
TH="------------------------------- ---------------- -------- --------"
while [ ${CVD} -lt ${NGPU} ] ; do
  GG=`printf "  GPU %d " ${CVD}`
  TT="${TT} ${GG}"
  TH="${TH} --------"
  let "CVD+=1"
done
echo "${TT}"
echo "${TH}"

# Print report data for PME (standard settings)
I=0
for SYS in ${PME_SYS} ; do
  TT=`printf "%-30.30s " ${SYS}`
  TT="${TT} PME (Standard)  "
  CVD=0
  while [ ${CVD} -lt ${NGPUP2} ] ; do
    let "IJ=${NGPUP2}*${I} + ${CVD}"
    GG=`printf "%8.8s" ${PMETIME[${IJ}]}`
    TT="${TT} ${GG}"
    let "CVD+=1"
  done
  echo "${TT}"
  let "I+=1"
done
echo

# Print report data for PME (optimized settings)
I=0
for SYS in ${PME_SYS} ; do
  TT=`printf "%-30.30s " ${SYS}`
  TT="${TT} PME (Optimized) "
  CVD=0
  while [ ${CVD} -lt ${NGPUP2} ] ; do
    let "IJ=${NGPUP2}*${I} + ${CVD}"
    GG=`printf "%8.8s" ${PMEOPTTIME[${IJ}]}`
    TT="${TT} ${GG}"
    let "CVD+=1"
  done
  echo "${TT}"
  let "I+=1"
done
echo

# Print report data for PME (standard settings, multiple GPUs)
I=0
for SYS in ${PME_SYS} ; do
  TT=`printf "%-30.30s " ${SYS}`
  TT="${TT} PME (x${NGPU}, Std. ) "
  CVD=0
  while [ ${CVD} -lt ${NGPUP2} ] ; do
    let "IJ=${NGPUP2}*${I} + ${CVD}"
    GG=`printf "%8.8s" ${mPMETIME[${IJ}]}`
    TT="${TT} ${GG}"
    let "CVD+=1"
  done
  echo "${TT}"
  let "I+=1"
done
echo

# Print report data for PME (optimized settings, multiple GPUs)
I=0
for SYS in ${PME_SYS} ; do
  TT=`printf "%-30.30s " ${SYS}`
  TT="${TT} PME (x${NGPU}, Opt. ) "
  CVD=0
  while [ ${CVD} -lt ${NGPUP2} ] ; do
    let "IJ=${NGPUP2}*${I} + ${CVD}"
    GG=`printf "%8.8s" ${mPMEOPTTIME[${IJ}]}`
    TT="${TT} ${GG}"
    let "CVD+=1"
  done
  echo "${TT}"
  let "I+=1"
done
echo

# Print report data for GB
I=0
for SYS in ${GB_SYS} ; do
  TT=`printf "%-30.30s " ${SYS}`
  TT="${TT}       GB        "
  CVD=0
  while [ ${CVD} -lt ${NGPUP2} ] ; do
    let "IJ=${NGPUP2}*${I} + ${CVD}"
    GG=`printf "%8.8s" ${GBTIME[${IJ}]}`
    TT="${TT} ${GG}"
    let "CVD+=1"
  done
  echo "${TT}"
  let "I+=1"
done
echo

# Print report data for GB, multiple GPUs
I=0
for SYS in ${GB_SYS} ; do
  TT=`printf "%-30.30s " ${SYS}`
  TT="${TT}     GB (x${NGPU})     "
  CVD=0
  while [ ${CVD} -lt ${NGPUP2} ] ; do
    let "IJ=${NGPUP2}*${I} + ${CVD}"
    GG=`printf "%8.8s" ${mGBTIME[${IJ}]}`
    TT="${TT} ${GG}"
    let "CVD+=1"
  done
  echo "${TT}"
  let "I+=1"
done
